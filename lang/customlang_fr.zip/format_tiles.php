<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://pad-epnak.tech
 *
 * @package    format
 * @subpackage tiles
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allcoursescomplypalette'] = 'Toutes les séquences ont déjà des couleurs de tuiles autorisées. Rien à réinitialiser. Assurez-vous d\'enregistrer toutes les modifications apportées aux couleurs autorisées avant de lancer la réinitialisation.';
$string['allowlabelconversion_desc'] = 'Si cette option est cochée, les formateurs auront une option dans les paramètres d\'édition de chaque étiquette pour convertir l\'étiquette en page.';
$string['allowphototiles_desc'] = 'Si cette option est sélectionnée, les formateurs pourront télécharger une photo qui servira de fond pour la tuile. Ils pourront toujours utiliser les icônes de tuiles standard, dans la même séquence. (Si elle n\'est pas sélectionnée, seules les icônes de tuiles seront autorisées et les autres paramètres de tuile photo ci-dessous seront ignorés.)';
$string['basecolour_help'] = 'La couleur définie ici sera appliquée à toutes les tuiles de la séquence. Les couleurs disponibles sont déterminées par l\'administrateur de votre site dans les réglages du plugin Tuiles';
$string['changedcolour'] = 'Couleur des tuiles par défaut pour la séquence {$a}';
$string['checkforproblemcourses'] = 'Rechercher et résoudre les problèmes de séquences';
$string['collapse'] = 'Réduire la séance';
$string['completionwarning'] = 'Vous avez activé le suivi de l\'achèvement au niveau de la séquence, mais au niveau de l\'activité individuelle, aucun élément n\'a activé le suivi, il n\'y a donc rien à suivre.';
$string['completionwarning_help'] = 'Vous devez rendre les éléments individuels traçables en les modifiant (sous Achèvement de l\'activité > Suivi de l\'achèvement) ou vous pouvez le faire en masse sous Administration des séquences > Achèvement de la séquence';
$string['completion_help'] = 'Une coche à droite d\'une activité peut être utilisée pour indiquer quand l\'activité est terminée (un cercle vide sera affiché si non). <br><br> Selon le réglage, une coche peut apparaître automatiquement lorsque vous avez terminé l\'activité selon les conditions définies par le formateur.<br><br> Dans d\'autres cas, vous pouvez cliquer sur le cercle vide lorsque vous pensez avoir terminé l\'activité. Celle-ci se transforme en une coche verte pleine. (Si vous cliquez de nouveau dessus, la coche se vide.)';
$string['coursetoomanysections'] = 'Attention aux éditeurs : cette séquence  a plus de tuiles que le maximum autorisé. Un maximum de {$a->max} sera montré aux stagiaires (jusqu\'à « {$a->tilename} ») (les éditeurs peuvent en voir plus).';
$string['courseusebarforheadings_help'] = 'Afficher un onglet coloré à gauche de l\'en-tête dans la séquence chaque fois qu\'un style d\'en-tête est sélectionné dans l\'éditeur de texte.';
$string['customcssdesc'] = 'CSS personnalisé pour l\'appliquer à la section du contenu de la séquence lorsque le format de la séquence est utilisé. Ceci ne sera pas validé, alors prenez soin d\'entrer un code valide. Par exemple : <p>li.activity.subtile.resource.pdf { background-color: orange !important; }</p>';
$string['defaultthiscourse'] = 'Par défaut pour cette séquence';
$string['defaulttileicon_help'] = 'L\'icône sélectionnée ici apparaîtra par défaut sur <em>toutes</em> les tuiles dans cette séquence. On peut définir des icônes différentes pour les tuiles en utilisant les différents réglages au niveau de chaque tuile.';
$string['displayfilterbar_error'] = 'Si vous n\'avez pas défini de résultats pour cette séquence, vous ne pouvez afficher qu\'une barre de filtre basée sur le nombre de tuiles, et non sur les résultats. Créez d\'abord quelques résultats, puis revenez ici. Voir';
$string['displayfilterbar_help'] = '<p>Lorsque sélectionné, s\'affichera automatiquement un tableau de boutons avant l\'écran de tuiles dans une séquence, que les utilisateurs peuvent cliquer pour filtrer les tuiles jusqu\'à une certaine plage.</p><p>Lorsque l\'option « basé sur les numéros de tuiles » est sélectionnée, une série de boutons sera affichée, par exemple un bouton pour tuiles 1-4, un bouton pour tuiles 5-8, etc.</p><p>Lorsque l\'option « basé sur les résultats de la séquence » est sélectionnée, il y a un bouton par résultat de la séquence. Chaque tuile peut être assignée à un résultat donné (et donc à un bouton donné) à partir de la page des paramètres de cette tuile.';
$string['entersection'] = 'Entrer dans la séance';
$string['filterboth'] = 'Afficher les boutons en fonction du nombre de tuiles et des résultats de la séquence';
$string['filteroutcomes'] = 'Afficher les boutons en fonction des résultats de la séquence';
$string['filteroutcomesrestore'] = 'La séquence d\'origine utilisait les résultats dans la barre de filtre, qui ne sont pas encore pris en charge pendant le processus de restauration. Le réglage de la barre de filtre a donc été modifié dans le parcours restauré. Si vous souhaitez utiliser les résultats pour filtrer les tuiles dans la séquence restaurée, veuillez configurer à nouveau les résultats. Le parcours initial n\'a pas été modifié.';
$string['followthemecolour_desc'] = 'Si le paramètre a la valeur oui, les formateurs n\'auront pas le choix avec ce plugin et toutes les couleurs des tuiles ci-dessous seront ignorées. Au lieu de cela, on tentera d\'obtenir la couleur principale de la marque du thème et d\'utiliser cette couleur à la place.';
$string['home'] = 'Accueil de la séquence';
$string['maxcoursesectionsallowed'] = 'Le nombre maximum de séances de séquence autorisées dans cet environnement est de {$ a}.';
$string['modalmodules_desc'] = 'Lancer ces modules de séquence dans une fenêtre modale. D\'autres modules pourraient être ajoutés dans une version ultérieure.';
$string['newsectionname'] = 'Nouveau nom pour la séance {$a}';
$string['nexttopic'] = 'Séance suivante';
$string['numberofsections'] = 'Nombre de séances dans la séquence';
$string['previoustopic'] = 'Séance précédente';
$string['problemcourses'] = 'Séquences où il y a des problèmes';
$string['problemcoursesintro'] = 'Les séquences suivantes ont des numéros de séance plus élevés que prévu. Veuillez utiliser les boutons ci-dessous pour résoudre les problèmes.';
$string['reopenlastsection_desc'] = 'Si coché, si un utilisateur revient sur une séquence, la dernière séance qu\'il avait ouverte sera ré-ouverte à l\'arrivée.';
$string['resetallcoursecolours'] = 'Réinitialiser toutes les couleurs de séquence';
$string['scheduleddeleteemptysections'] = 'La tâche de suppression des séances vides de la séquence a été planifiée. Veuillez réessayer plus tard.';
$string['tilecolourgeneral_descr'] = 'Ce réglage permet à l\'administrateur de déterminer les couleurs disponibles pour les formateurs dans leurs séquences. Pour désactiver une couleur, la régler sur noir (#000). Si vous modifiez les couleurs ici, aucune modification ne sera reportée dans les séquences existantes jusqu\'à ce que leur formateur n\'essaie de changer la couleur d\'une tuile, auquel cas seules les couleurs définies ici lui seront proposées.';
$string['usejseditingexpandcollapse_desc'] = 'Si cette option est sélectionnée, en mode édition, un formateur peut développer et réduire les tuiles d\'édition avec des transitions animées. Le contenu de la tuile sera chargé lors de l\'expansion, sans rechargement de page.';
$string['usejsnavforsinglesection_desc'] = 'Si cette case est cochée, tout appel pour une seule séance par page (&section=xx) sera traité en utilisant JavaScript, en lançant la page principale de la séquence, animée pour s\'ouvrir à la séance demandée via JS, plutôt que d\'appeler l\'ancienne page de séance unique PHP.';
