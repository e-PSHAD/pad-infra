<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://pad-epnak.tech
 *
 * @package    mod
 * @subpackage game
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allstudents'] = 'Tous les stagiaires $a';
$string['attemptsonly'] = 'Ne montrer que les stagiaires qui ont tenté';
$string['confighidecross'] = 'Définit si le jeu mots croisés est montré aux formateurs ou non';
$string['confighidecryptex'] = 'Définit si le jeu Cryptex est montré aux formateurs ou non';
$string['confighidehangman'] = 'Définit si le jeu du pendu est montré aux formateurs ou non';
$string['confighidehiddenpicture'] = 'Définit si le jeu « Image cachée » est montré aux formateurs ou non';
$string['confighidemillionaire'] = 'Définit si le jeu Qui veut gagner des millions est montré aux formateurs ou non';
$string['confighidesnakes'] = 'Définit si le jeu « Serpents et échelles » est montré aux formateurs ou non';
$string['confighidesudoku'] = 'Définit si le jeu du Sudoku est montré aux froamteurs ou non';
$string['gameopenclose_help'] = 'Les stagiaires ne peuvent débuter leurs tentatives qu\'après cette date et doivent les avoir terminées avant la date de fermeture.';
$string['glossary_only_approved'] = 'N\'utiliser que les articles de glossaire approuvés ou ceux du formateur';
$string['helpbookquiz'] = 'Quand le stagiaire répond correctement, il peut aller au chapitre suivant.';
$string['helpcross'] = 'Ce jeu récupère des mots d\'un Glossaire ou de questions de type réponse courte et génère des mots croisés aléatoires. Le formateur peut définir le nombre maximal de colonnes/lignes ou choisir les mots. Le stagiaire peut cliquer sur le bouton « Vérifier la grille » pour vérifier si les réponses sont correctes. Tous les mots croisés sont dynamiques donc sont différents pour chaque stagiaire.';
$string['helphangman'] = 'Ce jeu récupère des mots d\'un Glossaire ou de questions de type réponse courte et génère une grille de pendu. Le formateur peut définir le nombre maximal de mots de chaque partie, si la première ou la dernière lettre est affichée ou si la question ou la réponse est affichée à la fin.';
$string['only_teachers'] = 'Seuls les formateurs peuvent voir cette page';
